
// MENÚ DESPLEGABLE
const botonMenu = document.getElementById("botonMenu");
const navegacion = document.getElementById("navegacion");

if (botonMenu && navegacion) {
    botonMenu.addEventListener("click", () => {
        navegacion.classList.toggle("visible");

        const abierto = navegacion.classList.contains("visible");
        botonMenu.setAttribute("aria-expanded", abierto);
    });
}

// ELEMENTOS DEL CARRITO
const botonCarrito = document.getElementById("botonCarrito");
const panelCarrito = document.getElementById("panelCarrito");
const cerrarCarrito = document.getElementById("cerrarCarrito");
const fondoPanel = document.getElementById("fondoPanel");
const listaCarrito = document.getElementById("listaCarrito");
const cantidadCarrito = document.getElementById("cantidadCarrito");
const vaciarCarrito = document.getElementById("vaciarCarrito");
const totalCarrito = document.getElementById("totalCarrito");

// CARGAR PRODUCTOS GUARDADOS
let carrito = JSON.parse(
    localStorage.getItem("carritoDulceEquilibrio")
) || [];

// FORMATO DE PRECIOS 
function formatoPrecio(precio) {
    return precio.toLocaleString("es-CO", {
        style: "currency",
        currency: "COP",
        maximumFractionDigits: 0
    });
}

// guardar carro
function guardarCarrito() {
    localStorage.setItem(
        "carritoDulceEquilibrio",
        JSON.stringify(carrito)
    );
}

// abrir y cerrar
function abrirCarrito() {
    if (panelCarrito && fondoPanel) {
        panelCarrito.classList.add("abierto");
        fondoPanel.classList.add("visible");
    }
}

function cerrarPanel() {
    if (panelCarrito && fondoPanel) {
        panelCarrito.classList.remove("abierto");
        fondoPanel.classList.remove("visible");
    }
}

// ACTUALIZAR CARRITO
function actualizarCarrito() {
    const cantidad = carrito.length;

    const total = carrito.reduce(
        (suma, producto) => suma + producto.precio,
        0
    );

    if (cantidadCarrito) {
        cantidadCarrito.textContent = cantidad;
    }

    if (totalCarrito) {
        totalCarrito.textContent = formatoPrecio(total);
    }

    if (!listaCarrito) return;

    listaCarrito.innerHTML = "";

    if (carrito.length === 0) {
        listaCarrito.innerHTML =
            '<li class="carrito-vacio">Todavía no has agregado elementos.</li>';
    }

    carrito.forEach((producto, indice) => {
        const elemento = document.createElement("li");

        elemento.textContent =
            producto.nombre + " - " + formatoPrecio(producto.precio);

        const quitar = document.createElement("button");
        quitar.textContent = "Quitar";

        quitar.addEventListener("click", () => {
            carrito.splice(indice, 1);
            guardarCarrito();
            actualizarCarrito();
        });

        elemento.appendChild(quitar);
        listaCarrito.appendChild(elemento);
    });

    guardarCarrito();
}

// añadir products
document.querySelectorAll(".agregar-carrito").forEach((boton) => {
    boton.addEventListener("click", () => {
        const nombre = boton.dataset.producto;
        const precio = Number(boton.dataset.precio) || 0;

        carrito.push({
            nombre: nombre,
            precio: precio
        });

        actualizarCarrito();
    });
});

// EVENTOS DEL PANEL
if (botonCarrito) {
    botonCarrito.addEventListener("click", abrirCarrito);
}

if (cerrarCarrito) {
    cerrarCarrito.addEventListener("click", cerrarPanel);
}

if (fondoPanel) {
    fondoPanel.addEventListener("click", cerrarPanel);
}

if (vaciarCarrito) {
    vaciarCarrito.addEventListener("click", () => {
        carrito = [];
        guardarCarrito();
        actualizarCarrito();
    });
}

// mostrar los productos al abrir pag
actualizarCarrito();
