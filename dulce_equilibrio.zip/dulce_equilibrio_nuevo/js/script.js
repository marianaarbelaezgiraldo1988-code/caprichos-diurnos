// MENÚ DESPLEGABLE
const botonMenu = document.getElementById("botonMenu");
const navegacion = document.getElementById("navegacion");
if (botonMenu && navegacion) {
  botonMenu.addEventListener("click", () => {
    navegacion.classList.toggle("visible");
    botonMenu.setAttribute("aria-expanded", navegacion.classList.contains("visible"));
  });
}

// CARRITO COMPARTIDO ENTRE LAS PÁGINAS
const CLAVE_CARRITO = "carritoDulceEquilibrio";
let carrito = [];
try {
  const guardado = JSON.parse(localStorage.getItem(CLAVE_CARRITO) || "[]");
  carrito = Array.isArray(guardado) ? guardado : [];
} catch (error) {
  carrito = [];
}
const botonCarrito = document.getElementById("botonCarrito");
const panelCarrito = document.getElementById("panelCarrito");
const cerrarCarrito = document.getElementById("cerrarCarrito");
const fondoPanel = document.getElementById("fondoPanel");
const listaCarrito = document.getElementById("listaCarrito");
const cantidadCarrito = document.getElementById("cantidadCarrito");
const vaciarCarrito = document.getElementById("vaciarCarrito");
const totalCarrito = document.getElementById("totalCarrito");
function formatoPrecio(precio) {
  return Number(precio || 0).toLocaleString("es-CO", {style:"currency",currency:"COP",maximumFractionDigits:0});
}
function guardarCarrito() {
  try { localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito)); } catch (error) {}
}
function abrirCarrito() {
  if (panelCarrito && fondoPanel) { panelCarrito.classList.add("abierto"); fondoPanel.classList.add("visible"); }
}
function cerrarPanel() {
  if (panelCarrito && fondoPanel) { panelCarrito.classList.remove("abierto"); fondoPanel.classList.remove("visible"); }
}
function actualizarCarrito() {
  if (cantidadCarrito) cantidadCarrito.textContent = carrito.length;
  const total = carrito.reduce((suma, p) => suma + Number(p.precio || 0), 0);
  if (totalCarrito) totalCarrito.textContent = formatoPrecio(total);
  if (listaCarrito) {
    listaCarrito.innerHTML = "";
    if (!carrito.length) {
      const vacio = document.createElement("li"); vacio.className = "carrito-vacio"; vacio.textContent = "Todavía no has agregado elementos."; listaCarrito.appendChild(vacio);
    }
    carrito.forEach((producto, indice) => {
      const li = document.createElement("li");
      li.append(document.createTextNode(`${producto.nombre || "Producto"} - ${formatoPrecio(producto.precio)}`));
      const quitar = document.createElement("button"); quitar.type = "button"; quitar.textContent = "Quitar";
      quitar.addEventListener("click", () => { carrito.splice(indice,1); guardarCarrito(); actualizarCarrito(); });
      li.appendChild(quitar); listaCarrito.appendChild(li);
    });
  }
  guardarCarrito();
}
document.querySelectorAll(".agregar-carrito").forEach(boton => {
  boton.addEventListener("click", () => {
    carrito.push({nombre:boton.dataset.producto || "Producto", precio:Number(boton.dataset.precio) || 0});
    actualizarCarrito();
    abrirCarrito();
  });
});
if (botonCarrito) botonCarrito.addEventListener("click", abrirCarrito);
if (cerrarCarrito) cerrarCarrito.addEventListener("click", cerrarPanel);
if (fondoPanel) fondoPanel.addEventListener("click", cerrarPanel);
if (vaciarCarrito) vaciarCarrito.addEventListener("click", () => { carrito=[]; guardarCarrito(); actualizarCarrito(); });
actualizarCarrito();
