require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const Contacto = require('./modelos/Contacto');

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, 'dulce_equilibrio_nuevo');

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

//  páginas, estilos, imágenes y scripts.
app.use(express.static(FRONTEND_DIR));

// Recibe y guarda los mensajes del formulario de contacto.
app.post('/api/contacto', async (req, res) => {
  try {
    const nombre = String(req.body.nombre || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mensaje = String(req.body.mensaje || '').trim();
    const lugar = String(req.body.lugar || '').trim();

    if (nombre.length < 3 || nombre.length > 80) {
      return res.status(400).json({ mensaje: 'Escribe un nombre de entre 3 y 80 caracteres.' });
    }

    const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!emailValido || email.length > 120) {
      return res.status(400).json({ mensaje: 'Escribe un correo electrónico válido.' });
    }

    if (mensaje.length < 5 || mensaje.length > 1500) {
      return res.status(400).json({ mensaje: 'El mensaje debe tener entre 5 y 1500 caracteres.' });
    }

    const lugaresPermitidos = ['Medellin', 'Bogota', 'Cali'];
    if (lugar && !lugaresPermitidos.includes(lugar)) {
      return res.status(400).json({ mensaje: 'Selecciona una ciudad válida.' });
    }

    const nuevoContacto = new Contacto({ nombre, email, mensaje, lugar });
    await nuevoContacto.save();

    return res.status(201).json({
      mensaje: '¡Tu mensaje fue enviado correctamente! Gracias por contactarnos.'
    });
  } catch (error) {
    console.error('Error al guardar el contacto:', error);
    return res.status(500).json({
      mensaje: 'No pudimos guardar tu mensaje. Inténtalo nuevamente más tarde.'
    });
  }
});

// Comprueba el estado del servidor y de la conexión con MongoDB.
app.get('/api/status', (req, res) => {
  res.json({
    servidor: 'activo',
    mongodb: mongoose.connection.readyState === 1 ? 'conectado' : 'desconectado'
  });
});

async function iniciarServidor() {
  const mongoUri = process.env.MONGODB_URI;

  if (!mongoUri) {
    console.error('Falta MONGODB_URI. Crea un archivo .env usando .env.example como guía.');
    process.exit(1);
  }

  try {
    await mongoose.connect(mongoUri);
    console.log('MongoDB conectado correctamente.');

    app.listen(PORT, () => {
      console.log(`Dulce Equilibrio está disponible en http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('No se pudo conectar con MongoDB:', error.message);
    process.exit(1);
  }
}

iniciarServidor();
