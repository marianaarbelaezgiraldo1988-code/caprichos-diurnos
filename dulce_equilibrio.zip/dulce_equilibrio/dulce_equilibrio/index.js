const express = require('express');
const mongoose = require('mongoose')
const app = express();

const MONGODB_URL = 'mongodb+srv://marianaarbelaezgiraldo1988_db_user:<db_password>@mariana.x74xmmv.mongodb.net/Mariana'
const conectarDB = async () => {
    try {
        await mongoose.connect(MONGODB_URL);
        console.log('base de datos conectada');
    } catch (error) {
        console.log('Error conectando a MongoDB:', error.mensaje);
        process.exit(1);
    }
}

conectarDB();

app.get('/', (req, res) => { 
    res.send('Hellooo');
})

app.listen(3000, () => {
    console.log('servidor ejecutandose en http://localhost:3000');
})