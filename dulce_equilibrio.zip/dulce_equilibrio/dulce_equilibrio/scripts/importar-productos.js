// Lee los botones "agregar-carrito" de las páginas del sitio y crea los productos
// en MongoDB (si no existen ya con ese nombre). Se puede ejecutar varias veces.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const Producto = require('../modelos/Producto');

const SITIO = path.join(__dirname, '..', 'dulce_equilibrio_nuevo');
const PAGINAS = {
  'tortas': 'Tortas',
  'postres': 'Postres',
  'galletas': 'Galletas',
  'antojos creativos': 'Antojos creativos'
};

function leerAtributo(bloque, nombre) {
  const m = bloque.match(new RegExp(`${nombre}="([^"]*)"`, 'i'));
  return m ? m[1].trim() : '';
}

function encontrarProductos() {
  const encontrados = [];
  for (const [carpeta, categoria] of Object.entries(PAGINAS)) {
    const archivo = path.join(SITIO, carpeta, 'index.html');
    if (!fs.existsSync(archivo)) continue;
    const html = fs.readFileSync(archivo, 'utf8');

    const botones = html.match(/<button[^>]*agregar-carrito[^>]*>/gi) || [];
    for (const boton of botones) {
      const nombre = leerAtributo(boton, 'data-producto');
      const precio = Number(leerAtributo(boton, 'data-precio'));
      if (nombre && Number.isFinite(precio)) encontrados.push({ nombre, precio, categoria });
    }
  }
  return encontrados;
}

(async () => {
  try {
    if (!process.env.MONGODB_URI) throw new Error('Falta MONGODB_URI en el archivo .env.');
    await mongoose.connect(process.env.MONGODB_URI);

    let creados = 0;
    for (const p of encontrarProductos()) {
      const existe = await Producto.exists({ nombre: p.nombre });
      if (!existe) {
        await Producto.create(p);
        creados += 1;
      }
    }
    console.log(`Productos nuevos creados: ${creados}.`);
  } catch (error) {
    console.error('No se pudo importar:', error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
