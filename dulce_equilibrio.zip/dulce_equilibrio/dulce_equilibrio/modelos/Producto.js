const mongoose = require('mongoose');

const CATEGORIAS = ['Tortas', 'Postres', 'Galletas', 'Antojos creativos', 'Otros'];

const productoSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
    descripcion: { type: String, trim: true, maxlength: 300, default: '' },
    categoria: { type: String, enum: CATEGORIAS, default: 'Otros' },
    precio: { type: Number, required: true, min: 0, max: 10000000 },
    // Ruta relativa dentro del sitio, por ejemplo: assets/img/torta-naranja.jpg
    imagen: { type: String, trim: true, maxlength: 200, default: '' },
    disponible: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Producto', productoSchema);
module.exports.CATEGORIAS = CATEGORIAS;
