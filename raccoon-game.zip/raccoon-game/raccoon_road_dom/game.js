const game = document.getElementById('game');
const playerEl = document.getElementById('player');
const obstaclesEl = document.getElementById('obstacles');
const scoreEl = document.getElementById('score');
const overlay = document.getElementById('overlay');
const titleEl = document.getElementById('panel-title');
const textEl = document.getElementById('panel-text');
const startBtn = document.getElementById('start-btn');

const lanes = [39, 50, 61];
const keys = {left:false,right:false};
let playerLane = 1, obstacles = [], score = 0, speed = 27;
let spawnTimer = 0, running = false, lastTime = 0, animationId = 0;

function resetGame(){
  playerLane = 1; obstacles = []; score = 0; speed = 27; spawnTimer = 0; lastTime = 0;
  scoreEl.textContent = '0';
  playerEl.style.left = lanes[playerLane] + '%';
  obstaclesEl.replaceChildren();
}
function movePlayer(dir){
  if(!running) return;
  playerLane = Math.max(0, Math.min(2, playerLane + dir));
  playerEl.style.left = lanes[playerLane] + '%';
}
function spawnObstacle(){
  const lane = Math.floor(Math.random()*lanes.length);
  const img = document.createElement('img');
  const enemyType = Math.random() < .5 ? 1 : 2;
  img.className = 'sprite enemy' + enemyType;
  img.src = enemyType === 1
  ? 'assets/enemy1.png'
  : 'assets/enemy2.png';
  img.src = Math.random() < .5 ? 'assets/enemy1.png' : 'assets/enemy2.png';
  img.alt = 'Obstáculo';
  img.draggable = false;
  img.style.left = lanes[lane] + '%';
  img.style.top = '-12%';
  obstaclesEl.appendChild(img);
  obstacles.push({el:img,lane,top:-12,passed:false});
}
function overlaps(a,b){
  const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
  const insetX=Math.min(ar.width,br.width)*.2;
  const insetY=Math.min(ar.height,br.height)*.2;
  return ar.left+insetX < br.right-insetX && ar.right-insetX > br.left+insetX &&
         ar.top+insetY < br.bottom-insetY && ar.bottom-insetY > br.top+insetY;
}
function endGame(){
  running=false; cancelAnimationFrame(animationId);
  titleEl.textContent='¡Fin del viaje!';
  textEl.textContent=`Conseguiste ${score} puntos. ¿Intentamos superar tu récord?`;
  startBtn.textContent='VOLVER A JUGAR';
  overlay.classList.remove('hidden');
}
function update(dt){
  speed=Math.min(48,speed+dt*0.45);
  spawnTimer-=dt;
  if(spawnTimer<=0){spawnObstacle();spawnTimer=Math.max(.62,1.15-score*.008);}
  for(const o of obstacles){
    o.top+=speed*dt;
    o.el.style.top=o.top+'%';
    if(!o.passed && o.top>83){o.passed=true;score++;scoreEl.textContent=score;}
    if(o.lane===playerLane && overlaps(playerEl,o.el)){endGame();return;}
  }
  obstacles=obstacles.filter(o=>{
    if(o.top>115){o.el.remove();return false;}
    return true;
  });
}
function frame(time){
  if(!running)return;
  const dt=Math.min((time-(lastTime||time))/1000,.04);
  lastTime=time;update(dt);
  if(running)animationId=requestAnimationFrame(frame);
}
function startGame(){
  cancelAnimationFrame(animationId);resetGame();overlay.classList.add('hidden');
  running=true;animationId=requestAnimationFrame(frame);
}
function keyDown(e){
  if(['ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();
  if((e.key==='ArrowLeft'||e.key.toLowerCase()==='a')&&!keys.left){keys.left=true;movePlayer(-1);}
  if((e.key==='ArrowRight'||e.key.toLowerCase()==='d')&&!keys.right){keys.right=true;movePlayer(1);}
}
function keyUp(e){
  if(e.key==='ArrowLeft'||e.key.toLowerCase()==='a')keys.left=false;
  if(e.key==='ArrowRight'||e.key.toLowerCase()==='d')keys.right=false;
}
window.addEventListener('keydown',keyDown);
window.addEventListener('keyup',keyUp);
window.addEventListener('blur',()=>{keys.left=false;keys.right=false;});
document.getElementById('left-btn').addEventListener('click',()=>movePlayer(-1));
document.getElementById('right-btn').addEventListener('click',()=>movePlayer(1));
startBtn.addEventListener('click',startGame);
resetGame();
